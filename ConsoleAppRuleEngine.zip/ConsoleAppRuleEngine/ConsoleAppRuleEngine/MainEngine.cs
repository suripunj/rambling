﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using ConsoleAppRuleEngine.Entity;

namespace ConsoleAppRuleEngine
{
    class MainEngine
    {
        private static MainEngine _Instance;
        protected MainEngine() { }


        public static MainEngine Instance()
        {
           
            if (_Instance == null)
            {
                _Instance = new MainEngine();
            }

            return _Instance;
        }
        public void RunRule<T>(InterfaceProductEntities<T> fp)
        {
        
        foreach(var rule in fp.RuleDirectory)
        {
            Console.WriteLine("\n" + rule.ToString());
            Console.WriteLine("-----------------------------------------------------------------------");
            var result = fp.ListFpProduct.Where(rule.Visit()); 
            foreach (var x in result)
            Console.WriteLine(x.ToString());
            Console.WriteLine("-----------------------------------------------------------------------");

        }
        
        }
    }
}
