﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using ConsoleAppRuleEngine.Entity;
using ConsoleAppRuleEngine.Rules;
using System.Linq.Expressions;

namespace ConsoleAppRuleEngine
{
    class Program
    {
        static void Main(string[] args)
        {

            FpProductsEntities fpent = new FpProductsEntities();
            fpent.LoadDate();
            fpent.AttachRule(new ClassVisitValidateField<FpProduct>("Rule1", "ProductTotalAmount", ExpressionType.GreaterThanOrEqual, "2000"));
            fpent.AttachRule(new ClassVisitCompareFields<FpProduct>("Rule2","ProductTotalAmount",ExpressionType.LessThanOrEqual,1,"ProductBalanceAmount"));
            fpent.AttachRule(new ClassVisitCompareFields<FpProduct>("Rule2", "ProductTotalAmount", ExpressionType.GreaterThan, 1, "ProductBalanceAmount"));
            MainEngine.Instance().RunRule(fpent);
            Console.ReadLine();
         
        

        }
    }
}
