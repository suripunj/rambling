﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using ConsoleAppRuleEngine.Entity;

namespace ConsoleAppRuleEngine.Rules
{
    interface InterfaceVisitor<T>
    {
        Func<T, bool> Visit();
    }
}
