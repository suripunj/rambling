﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Linq.Expressions;
using ConsoleAppRuleEngine.Entity;
namespace ConsoleAppRuleEngine.Rules
{
    class ClassVisitValidateField<T> : InterfaceVisitor<T>
    {
        public string _ruleiD { get; set; }
        public string _propertyName { get; set; }
        public ExpressionType _ExpOperator {get ; set;}
        public string  _PropertyValue { get; set; }

        public ClassVisitValidateField(string ruleid, string PropertyName, ExpressionType exp, string PropertyValue)
        {
            _ruleiD = ruleid;
            _propertyName = PropertyName;
            _ExpOperator = exp;
            _PropertyValue = PropertyValue;
        }

        public Func<T, bool> Visit()  /// here find out what type the list is containing .
        {
           var parameterExpression = Expression.Parameter(typeof(T), "FinanacialProduct");
           var property = Expression.Property(parameterExpression, _propertyName);
           var propertyType = typeof(T).GetProperty(_propertyName).PropertyType;
           var constant = Expression.Constant(Convert.ChangeType(_PropertyValue, propertyType));
           var binaryExpression = Expression.MakeBinary(_ExpOperator, property, constant);
           var lambda = Expression.Lambda<Func<T, bool>>(binaryExpression, parameterExpression);
           return lambda.Compile();
          }

        public override string ToString()
        {
            return "Rule Id: " + _ruleiD + ">" + _propertyName + "  Should be " + _ExpOperator.ToString() +" " + _PropertyValue;

        }

    }

    
}
