﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Linq.Expressions;

namespace ConsoleAppRuleEngine.Rules
{
    class ClassVisitCompareFields<T> : InterfaceVisitor<T>
    {
        public string _ruleid { get; set; }
        public string _leftProperty { get; set; }
        public string _rightProperty { get; set; }
        public double _factorProperty { get; set; }
        public ExpressionType _ExpOperator {get ; set;}

        public ClassVisitCompareFields(string ruleId ,string leftField,ExpressionType expOperator,int factor,string rightProperty)
        {
            _ruleid=ruleId;
            _leftProperty=leftField;
            _ExpOperator=expOperator;
            _factorProperty =factor;
            _rightProperty=rightProperty;
        
        }

        public Func<T, bool> Visit() 
        {
            var parameterExpression = Expression.Parameter(typeof(T), "FinanacialProduct");
            var propertyleft = Expression.Property(parameterExpression, _leftProperty);
            var propertyRight = Expression.Property(parameterExpression, _rightProperty);
            var binaryRight = Expression.Multiply(propertyRight, Expression.Constant(_factorProperty));
            var binaryExpression = Expression.MakeBinary(_ExpOperator, propertyleft, binaryRight);
            var lambda = Expression.Lambda<Func<T, bool>>(binaryExpression, parameterExpression);
            return lambda.Compile();
        
        }

        public override string ToString()
        {
            return "Rule Id: " + _ruleid + ">" + _leftProperty + "  Should be " + _ExpOperator.ToString() + "  " + _factorProperty + "  times  " + _rightProperty;

        }
    }
}
