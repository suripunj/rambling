﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using ConsoleAppRuleEngine.Rules;

namespace ConsoleAppRuleEngine.Entity
{
    interface InterfaceProductEntities<T>
    {
         List<T> ListFpProduct { get; set; }
         List<InterfaceVisitor<T>> RuleDirectory { get; set; }

    }
}
