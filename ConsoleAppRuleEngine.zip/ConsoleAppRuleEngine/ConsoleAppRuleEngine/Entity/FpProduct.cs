﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleAppRuleEngine.Entity
{
    class FpProduct 
    {
        public string ProductiD { get; set; }
        public string ProductName { get; set; }
        public string ProductType { get; set; }
        public double ProductTotalAmount { get; set; }
        public double ProductBalanceAmount { get; set; }
        public int ProductTenure { get; set; }

        public FpProduct(string Productid, string ProdName, string ProdType, double ProdTotalAmount, 
            double ProdBalanceAmount, int ProdTenure)
        {
            ProductiD = Productid;
            ProductName = ProdName;
            ProductType = ProdType;
            ProductTotalAmount = ProdTotalAmount;
            ProductBalanceAmount = ProdBalanceAmount;
            ProductTenure = ProdTenure;

        }

        public override string ToString()
        {
            return "Product id: "+ProductiD + "  Product Name:"  + ProductName+ " Product Type: "+ ProductType + 
            " Product Total Amount: "+ProductTotalAmount+ " Product Balance Amount: "+ProductBalanceAmount + " Product Tenure: " +ProductTenure;
        }
    }

   
}
