﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using ConsoleAppRuleEngine.Rules;

namespace ConsoleAppRuleEngine.Entity
{
    class FpProductsEntities :InterfaceProductEntities<FpProduct>
    {
        public List<FpProduct> ListFpProduct { get; set; }
        public List<InterfaceVisitor<FpProduct>> RuleDirectory { get; set; }
        public void AttachRule(InterfaceVisitor<FpProduct> Rule)
        {
            if (RuleDirectory == null)
                RuleDirectory = new List<InterfaceVisitor<FpProduct>>();

            RuleDirectory.Add(Rule);
        }

        public void LoadDate()
        {

            if (ListFpProduct == null)
            {
                ListFpProduct = new List<FpProduct>();
            }
                ListFpProduct.Add(new FpProduct("Prd1", "Loan0Tom2019", "Loan", 2000, 1500, 1));
                ListFpProduct.Add(new FpProduct("Prd2", "Loan0Moody2017", "USLease", 12000, 150, 1));
                ListFpProduct.Add(new FpProduct("Prd3", "Loan0Tom2018", "SLoan", 2000, 1500, 1));
                ListFpProduct.Add(new FpProduct("Prd4", "Loan0Rex2018", "LLoan", 20000, 1500, 1));
                ListFpProduct.Add(new FpProduct("Prd5", "Loan0Ahuja2020", "CarLoan", 9000, 15000, 1));
                ListFpProduct.Add(new FpProduct("Prd6", "Loan0Pat2019", "Loan", 7000, 1500, 1));            
            }

        

        
        }
    }

